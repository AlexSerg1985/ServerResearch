package ru.mdimension.wrs.storage.web.rest;

import io.minio.MinioClient;
import io.minio.errors.MinioException;
import io.minio.policy.PolicyType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.xmlpull.v1.XmlPullParserException;

import javax.inject.Inject;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping("/bucketService")
public class BucketResource {

    private final static Logger log = LoggerFactory.getLogger(BucketResource.class);

    @Inject
    private MinioClient minioClient;

    @RequestMapping(value = "/folders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> create(@RequestBody FolderDTO folderDTO) throws RepositoryException {
        Session session = repository.login(new SimpleCredentials("admin", "admin".toCharArray()));
        if(JcrUtils.getNodeIfExists(folderDTO.getUrl(), session) == null) {
            throw new BadRequestException("EFFC1", "The specified parent node was not found on the server");
        }
        Node parentNode = session.getNode(folderDTO.getUrl());
        if(JcrUtils.getNodeIfExists(parentNode, folderDTO.getName()) != null) {
            throw new BadRequestException("EFFC2", "The specified folder already exists within the specified folder");
        }
        Node newNode = parentNode.addNode(folderDTO.getName(), NodeType.NT_FOLDER);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.LINK, newNode.getPath());
        session.save();
        session.logout();
        return new ResponseEntity<>(headers, HttpStatus.OK);
    }

    private void createBucket(final String name) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        if (bucketExist(name)) {
            minioClient.makeBucket(name);
            log.debug("The bucket with name ".concat(name).concat(" have been created"));
        }
        else {
            log.debug("The bucket with name ".concat(name).concat(" already exist"));
        }
    }

    private boolean bucketExist(final String name) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        boolean found = minioClient.bucketExists(name);
        return found;
    }

    private void setupBucketPolicy(final String name, final String prefix, final PolicyType type) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        minioClient.setBucketPolicy(name, prefix, type);
    }

    private void removeBucket(final String name, final String prefix, final PolicyType type) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        if (bucketExist(name)) {
            minioClient.removeBucket(name);
            log.debug("The bucket with name ".concat(name).concat(" have been created"));
        }
        else {
            log.debug("The bucket with name ".concat(name).concat(" already exist"));
        }
    }
}
