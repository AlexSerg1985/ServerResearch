package ru.mdimension.wrs.storage.web.dto;

import com.google.api.client.util.Key;
import io.minio.messages.Bucket;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class BucketDTO {

    private String name;

    private String creationDate;

    private Set<BucketDTO> buckets = new HashSet<>();

    public BucketDTO() {}

    public BucketDTO(final Bucket bucket) throws RepositoryException {
        this.name = bucket.name();
        this.setCreationDate(bucket.creationDate());
        for(Node n: JcrUtils.getChildNodes(node)) {
            if(n.getPrimaryNodeType().toString().equals("nt:file")) {
                files.add(new FileDTO(n));
            }
        }
        this.folders = parseFoldersFromNode(node);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(final String creationDate) {
        this.creationDate = creationDate;
    }

    public void setCreationDate(final Date creationDate) {
        this.creationDate = DateFormatUtils.format(creationDate, "yyyy-MM-dd'T'HH':'mm':'ss'.'SSS'Z'");
    }

    @Override
    public String toString() {
        return "FolderDTO{" +
                "name='" + name + '\'' +
                ", url='" + creationDate + '\'' +
                ", files=" + files +
                ", folders=" + folders +
                '}';
    }
}
