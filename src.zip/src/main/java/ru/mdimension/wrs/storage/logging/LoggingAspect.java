package ru.mdimension.wrs.storage.logging;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import ru.mdimension.wrs.core.aop.logging.AspectSettings;
import ru.mdimension.wrs.core.aop.logging.LoggingCoreAspect;
import ru.mdimension.wrs.core.aop.logging.MethodCallStatistics;

@Aspect
public class LoggingAspect extends LoggingCoreAspect {
    public LoggingAspect(MethodCallStatistics methodCallStatistics, AspectSettings aspectSettings) {
        super(methodCallStatistics, aspectSettings);
    }

    @Override
    @Pointcut("within(ru.mdimension.wrs.storage.api..*) || within(ru.mdimension.wrs.storage.repository..*) || within" +
            "(ru.mdimension.wrs.storage.service..*)")
    public void loggingPointcut() {
    }
}
