package ru.mdimension.wrs.storage;

public class ApplicationWebXmlHelper {
}
