package ru.mdimension.wrs.storage.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.io.IOException;

@Service
public class RabbitMQService {

    private static final Logger log = LoggerFactory.getLogger(RabbitMQService.class);

    @Inject
    private RabbitTemplate rabbitTemplate;

    @Inject
    private ObjectMapper objectMapper;

    public void convertAndSend(String exchangeName, String routingName, Object message) {
        String msg;
        try {
            msg = objectMapper.writer().writeValueAsString(message);
            rabbitTemplate.convertAndSend(exchangeName, routingName, msg);
        } catch(IOException ioe) {
            log.debug("Could not convert and send msg {} on exchange {} for route {}", message, exchangeName, routingName);
        }
    }

}