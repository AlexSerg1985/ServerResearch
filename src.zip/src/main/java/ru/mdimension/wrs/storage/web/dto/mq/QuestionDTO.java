package ru.mdimension.wrs.storage.web.dto.mq;

/**
 * Created by vkokurin on 10.11.2015.
 */
public class QuestionDTO {

    private Integer checklistId;

    private Integer questionId;

    private Boolean hasPhoto;

    public QuestionDTO() {}

    public QuestionDTO(Integer checklistId, Integer questionId, Boolean hasPhoto) {
        this.checklistId = checklistId;
        this.questionId = questionId;
        this.hasPhoto = hasPhoto;
    }

    public Integer getChecklistId() {
        return checklistId;
    }

    public void setChecklistId(Integer checklistId) {
        this.checklistId = checklistId;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public Boolean getHasPhoto() {
        return hasPhoto;
    }

    public void setHasPhoto(Boolean hasPhoto) {
        this.hasPhoto = hasPhoto;
    }

    @Override
    public String toString() {
        return "QuestionDTO{" +
                "checklistId=" + checklistId +
                ", questionId=" + questionId +
                ", hasPhoto=" + hasPhoto +
                '}';
    }
}