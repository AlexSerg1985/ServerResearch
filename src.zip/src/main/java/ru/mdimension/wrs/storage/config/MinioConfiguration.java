package ru.mdimension.wrs.storage.config;

import io.minio.MinioClient;
import io.minio.errors.InvalidEndpointException;
import io.minio.errors.InvalidPortException;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class MinioConfiguration implements EnvironmentAware {

    private RelaxedPropertyResolver propertyResolver;

    @Override
    public void setEnvironment(Environment environment) {
        propertyResolver = new RelaxedPropertyResolver(environment, "storage.minio.");
    }

    @Bean
    public MinioClient minioClient() throws InvalidPortException, InvalidEndpointException {
        return new MinioClient(
                propertyResolver.getProperty("host", String.class, "minio"),
                Integer.parseInt(propertyResolver.getProperty("port", String.class, "9999")),
                propertyResolver.getProperty("accessKey", String.class, "minio"),
                propertyResolver.getProperty("secretKey", String.class, "miniominio"), false);
    }

}
