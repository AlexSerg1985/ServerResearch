package ru.mdimension.wrs.storage;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan("ru.mdimension.wrs.storage")
public class StoreConfiguration {

}
