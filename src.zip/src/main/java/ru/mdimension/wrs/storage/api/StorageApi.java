package ru.mdimension.wrs.storage.api;

import javax.annotation.Nonnull;
import java.io.InputStream;

public interface StorageApi {


    boolean saveObject(@Nonnull String bucket, @Nonnull String objectName, byte[] object, @Nonnull String contentType);

    byte[] getObject(@Nonnull String bucket, @Nonnull String objectName);

    InputStream getObjectInputStream(@Nonnull String bucket, @Nonnull String objectName);

    boolean deleteObject(@Nonnull String bucket, @Nonnull String objectName);

}
