package ru.mdimension.wrs.storage.repository;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import ru.mdimension.wrs.storage.domain.StorageInfo;

import java.util.List;

public interface StorageRepository extends JpaRepository<StorageInfo, Integer> {

    List<StorageInfo> findByUserLogin(String userLogin);

    StorageInfo findByFileName(String fileName);

    long deleteByFileName(String fileName);

    @Query("select t from StorageInfo t where t.bucketName = ?1 and t.createDate <= ?2")
    List<StorageInfo> getFilesForBucketAndOlderThen(String bucketName, DateTime date);

}
