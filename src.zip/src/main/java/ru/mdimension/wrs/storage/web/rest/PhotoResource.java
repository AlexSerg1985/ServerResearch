package ru.mdimension.wrs.storage.web.rest;

import io.minio.MinioClient;
import io.minio.errors.MinioException;
import io.minio.messages.Bucket;
import io.minio.messages.Item;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.hibernate.Session;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.xmlpull.v1.XmlPullParserException;
import ru.mdimension.wrs.core.exception.BadRequestException;
import ru.mdimension.wrs.storage.domain.StorageInfo;
import ru.mdimension.wrs.storage.properties.RabbitMQProperties;
import ru.mdimension.wrs.storage.service.RabbitMQService;
import ru.mdimension.wrs.storage.web.dto.PhotoCollectionDTO;

import org.apache.commons.io.IOUtils;
import ru.mdimension.wrs.storage.web.dto.mq.QuestionDTO;

import javax.inject.Inject;
import java.io.*;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@RestController
@RequestMapping("/photoService")
public class PhotoResource {
    private static final Logger log = LoggerFactory.getLogger(PhotoResource.class);

    private static final Integer DAYS_FROM_SAVE_PHOTO = 30;
    private static final Integer DAYS_FROM_SAVE_PHOTO_AG = 11;
    private static final String PROPERTIES_FILE_NAME = "photosetting.properties";
    private static final String PROPERTIES_PROP_DAYS = "days";
    private static final String PROPERTIES_PROP_DAYS_AG = "days_ag";
    private static final String NODE_NAME_PHOTO = "photo";
    private static final String NODE_NAME_PHOTO_AG = "photoAG";
    private static final DateTimeFormatter fmt = ISODateTimeFormat.dateTime().withZone(DateTimeZone.UTC);
    private static final String basePath = "/photoService"

    @Inject
    private MinioClient minioClient;

    @Inject
    private RabbitMQService rabbitMQService;

    @Inject
    private RabbitMQProperties rabbitMQProperties;

    @Inject
    private Repository repository;

    @ApiOperation(
            value = "АГ - фотография проверки магазина",
            notes = "Возвращает фотографию из проверки магазина"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 204, message = "Нет указанной фотографии")
    })
    @RequestMapping(value = "/photoAG", method = RequestMethod.GET)
    public ResponseEntity<byte[]> getAgByShop(
            @ApiParam(value = "id магазина")
            @RequestParam("shopId") Integer shopId,
            @ApiParam(value = "id фотографии")
            @RequestParam(value = "photoId", required = true) String photoId) throws RepositoryException, IOException {
        Session session = null;
        try {
            session = getSession();

            Node photoRootNode = getPhotoAgNode(session);
            if (photoRootNode == null) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            Node shopNode = JcrUtils.getNodeIfExists(photoRootNode, shopId.toString());
            if (shopNode == null) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            Node photoNode = JcrUtils.getNodeIfExists(shopNode, photoId);
            if (photoNode == null) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            String date = photoNode.getProperty("created").getString();
            String name = "Проверка в магазине от " + date + ".jpeg";
            String type = photoNode.getProperty("type").getString();
            byte[] img = IOUtils.toByteArray(photoNode.getProperty("img").getBinary().getStream());
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=" + URLEncoder.encode(name, "UTF-8"))
                    .header("Content-Description", "File Transfer")
                    .header("Set-Cookie", "fileDownload=true; path=/")
                    .contentType(MediaType.parseMediaType(type))
                    .body(img);
        }
        catch (Exception e) {
            log.error("Get AG photo error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new byte[1]);
        }
        finally {
            if (session != null)
                session.logout();
        }
    }


    //    @PreAuthorize("isAuthenticated()")
    @ApiOperation(
            value = "АГ - фотографии проверки магазина",
            notes = "Возвращает список фотографий из проверки магазина (сами фото в base64)"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok", response = PhotoCollectionDTO.class, responseContainer = "List"),
            @ApiResponse(code = 400, message = "Нет фотографий")
    })
    @RequestMapping(value = "/photosAG", method = RequestMethod.GET)
    public ResponseEntity<List<PhotoCollectionDTO>> getsAgByShop(
            @ApiParam(value = "id магазина")
            @RequestParam("shopId") Integer shopId,
            @ApiParam(value = "флаг возвращать ли сами фотографии")
            @RequestParam(value = "get_data", defaultValue = "true") Boolean data) throws RepositoryException, IOException {

        if (shopId == null) {
            throw new BadRequestException("ERROR_CODE_04", "is no incoming ID");
        }

        Session session = null;
        try {
            session = getSession();
            Node photoRootNode = getPhotoAgNode(session);
            if (photoRootNode == null) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            Node shopNode = JcrUtils.getNodeIfExists(photoRootNode, shopId.toString());
            if (shopNode == null) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            NodeIterator nodes = shopNode.getNodes();
            List<PhotoCollectionDTO> photoCollectionDTOs = new LinkedList<>();
            while (nodes.hasNext()) {
                Node photoNode = nodes.nextNode();
                String type = photoNode.getProperty("type").getString() + ";base64,";
                byte[] img = new byte[0];
                if (data) {
                    byte[] imgs = img = IOUtils.toByteArray(photoNode.getProperty("img").getBinary().getStream());
                }
                photoCollectionDTOs.add(new PhotoCollectionDTO(null, photoNode.getName(), img, type));
            }
            session.save();
            return new ResponseEntity<>(photoCollectionDTOs, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Get AG photos error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } finally {
            if (session != null)
                session.logout();
        }
    }

    //    @PreAuthorize("isAuthenticated()")
    @ApiOperation(
            value = "АГ - сохраняет фотографию из проверки магазина",
            notes = "Сохраняет фотографию из проверки магазина на сервере. " +
                    "Фотография должна быть в формате jpeg. " +
                    "В случае успеха возвращает в заголовке параметр Link с внутренним путём к фотографии"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
    })
    @RequestMapping(value = "/photoAG", method = RequestMethod.POST)
    public ResponseEntity<Void> createAG(
            @ApiParam(value = "id магазина")
            @RequestParam("shopId") Integer shopId,
            @ApiParam(value = "файл фотографии (multipart-data)")
            @RequestParam("file") MultipartFile file) throws BadRequestException {

        if (file == null) {
            throw new BadRequestException("ERROR_CODE_01", "There is no incoming photos");
        }

        if (shopId == null) {
            throw new BadRequestException("ERROR_CODE_02", "There is no incoming Shop ID");
        }

        HttpHeaders headers = new HttpHeaders();
        try {
            String contentType = "image/jpeg";
            final DateTime current = DateTime.now();
            String photoId = UUID.randomUUID().toString();
            String bucketName = shopId.toString();
            StorageInfo storageInfo = new StorageInfo();
            storageInfo.setFileName(file.getName());
            storageInfo.setContentType(contentType);
            storageInfo.setBucketName(shopId.toString());
            storageInfo.setCreateDate(current);
            this.savePhoto(shopId.toString(), file.getName(), contentType, file);

            final StringBuilder sb = new StringBuilder(basePath);
            sb.append("/");
            sb.append(bucketName);
            sb.append("/file/");
            sb.append(file.getName());
            headers.add(HttpHeaders.LINK, sb.toString());

            return new ResponseEntity<>(headers, HttpStatus.OK);
        }
        catch (Exception e) {
            log.error("Create AG photo error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //    @PreAuthorize("isAuthenticated()")
    @RequestMapping(value = "/photo", method = RequestMethod.POST)
    public ResponseEntity<Void> create(@RequestParam("checkListId") Integer checkListId,
                                       @RequestParam("questionId") Integer questionId,
                                       @RequestParam("file") MultipartFile file) throws RepositoryException, IOException {
        if (file == null) {
            throw new BadRequestException("ERROR_CODE_01", "There is no incoming photos");
        }

        if (checkListId == null) {
            throw new BadRequestException("ERROR_CODE_02", "There is no incoming CheckList ID");
        }

        if (questionId == null) {
            throw new BadRequestException("ERROR_CODE_03", "There is no incoming Question ID");
        }

        Session session = null;
        HttpHeaders headers = new HttpHeaders();
        try {
            String contentType = file.getContentType() + ";base64,";
            final DateTime current = DateTime.now();
            String photoId = UUID.randomUUID().toString();
            final String bucketName = new StringBuilder(checkListId).append("/").append(questionId).toString();

            this.savePhoto(bucketName, file.getName(), contentType, file);

            final StringBuilder sb = new StringBuilder(basePath);
            sb.append("/");
            sb.append(bucketName);
            sb.append("/file/");
            sb.append(file.getName());
            headers.add(HttpHeaders.LINK, sb.toString());

            rabbitMQService.convertAndSend(rabbitMQProperties.getExchanges().getWrsExchangePhoto(), "", new QuestionDTO(checkListId, questionId, true));
            return new ResponseEntity<>(headers, HttpStatus.OK);
        }
        catch (Exception e) {
            log.error("Create photo error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //    @PreAuthorize("isAuthenticated()")
    @RequestMapping(value = "/checklistPhotos", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<PhotoCollectionDTO>> getAllFromCheckLists(@RequestParam(value = "checklistId") Integer checkListId,
                                                                         @RequestParam(value = "get_data", defaultValue = "true") Boolean data) throws RepositoryException, IOException {

        if (checkListId == null) {
            throw new BadRequestException("ERROR_CODE_04", "is no incoming  ID");
        }

        try {
            List<PhotoCollectionDTO> photoCollectionDTOs = this.findAllByChecklistId(checkListId);
            /*while (nodes.hasNext()) {
                Node questionNode = nodes.nextNode();
                NodeIterator photoNodes = questionNode.getNodes();
                while (photoNodes.hasNext()) {
                    Node photoNode = photoNodes.nextNode();
                    String type = photoNode.getProperty("type").getString();
                    byte[] img = new byte[0];
                    if (data) {
                        img = IOUtils.toByteArray(photoNode.getProperty("img").getBinary().getStream());
                    }
                    photoCollectionDTOs.add(new PhotoCollectionDTO(questionNode.getName(), photoNode.getName(), img, type));
                }
            }*/
            if (photoCollectionDTOs.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(photoCollectionDTOs, HttpStatus.OK);
        }
        catch (Exception e) {
            log.error("Get checklist photos error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //    @PreAuthorize("isAuthenticated()")
    @RequestMapping(value = "/questionPhotos", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<PhotoCollectionDTO>> getAllFromQuestions(@RequestParam(value = "checklistId") Integer checkListId,
                                                                        @RequestParam(value = "questionId") Integer questionId,
                                                                        @RequestParam(value = "get_data", defaultValue = "true") Boolean data) throws RepositoryException, IOException {
        HttpHeaders headers = new HttpHeaders();

        if (checkListId == null) {
            return new ResponseEntity<List<PhotoCollectionDTO>>(headers, HttpStatus.BAD_REQUEST);
        }

        if (questionId == null) {
            return new ResponseEntity<List<PhotoCollectionDTO>>(headers, HttpStatus.BAD_REQUEST);
        }

        try {
            List<PhotoCollectionDTO> photoCollectionDTOs = this.findByChecklistAndQuestionId(checkListId, questionId);

            if (photoCollectionDTOs.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            /*NodeIterator photoNodes = questionNode.getNodes();
            while (photoNodes.hasNext()) {
                Node photoNode = photoNodes.nextNode();
                String type = photoNode.getProperty("type").getString();
                byte[] img = new byte[0];
                if (data) {
                    img = IOUtils.toByteArray(photoNode.getProperty("img").getBinary().getStream());
                }
                photoCollectionDTOs.add(new PhotoCollectionDTO(questionNode.getName(), photoNode.getName(), img, type));
            }*/

            return new ResponseEntity<>(photoCollectionDTOs, HttpStatus.OK);
        }
        catch (Exception e) {
            log.error("Get question photos error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //    @PreAuthorize("isAuthenticated()")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public ResponseEntity<Void> delete(@RequestParam(value = "checklistId") Integer checkListId,
                                       @RequestParam(value = "questionId") Integer questionId,
                                       @RequestParam(value = "photoId") String photoId
    ) throws RepositoryException {

        if (photoId == null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        if (checkListId == null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        if (questionId == null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        try {
            session = getSession();
            Node photoRootNode = getPhotoNode(session);
            if (photoRootNode == null) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            Node questionNode = photoRootNode.getNode(checkListId.toString()).getNode(questionId.toString());
            questionNode.getNode(photoId).remove();

            if (questionNode.getNodes().getSize() == 0) {
                rabbitMQService.convertAndSend(rabbitMQProperties.getExchanges().getWrsExchangePhoto(), null, new QuestionDTO(checkListId, questionId, false));
            }

            return new ResponseEntity<>(HttpStatus.OK);
        }
        catch (Exception e) {
            log.error("Delete photo error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //    @PreAuthorize("isAuthenticated()")
    @RequestMapping(value = "/setDaysFromPhoto", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> setDaysFromPhoto(@RequestParam(value = "days") Integer days) {
        setDaysFromPhoto(days, PROPERTIES_PROP_DAYS);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //    @PreAuthorize("isAuthenticated()")
    @ApiOperation(
            value = "АГ - сохраняет кол-во дней хранения фотографий",
            notes = "Сохраняет кол-во дней, в течение которых фотографии храняться на сервере"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
    })
    @RequestMapping(value = "/setDaysFromPhotoAG", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> setDaysFromPhotoAG(
            @ApiParam(name = "кол-во дней")
            @RequestParam(value = "days") Integer days) {
        setDaysFromPhoto(days, PROPERTIES_PROP_DAYS_AG);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    private void setDaysFromPhoto(Integer days, String propertyName) {
        try {
            Properties prop = getFileProperties();
            File file = new File(PROPERTIES_FILE_NAME);
            prop.setProperty(propertyName, days.toString());
            prop.store(new FileOutputStream(file), "The number of " + propertyName + " to store photos");
        } catch (IOException e) {
            log.error("IO error: create or read file photosetting.properties", e);
        }
    }


    @RequestMapping(value = "/getDaysFromPhoto", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> getDaysFromPhoto() {
        return new ResponseEntity<>(getDaysFromSavePhoto(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getDaysFromPhotoAG", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(
            value = "АГ - возвращает кол-во дней хранения фотографий",
            notes = "Возвращает кол-во дней, в течение которых фотографии храняться на сервере"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
    })
    public ResponseEntity<Integer> getDaysFromPhotoAG() {
        return new ResponseEntity<>(getDaysFromSavePhotoAG(), HttpStatus.OK);
    }

    @Scheduled(cron = "0 0 0 * * ?")
    public void deleteOldPhotos() throws RepositoryException {
//        deletePhoto(); //аннотация @EnableScheduling не была указана в конфигурации и поэтому эта задача никогда не запускалась. Отключим её на всякий случай
        try {
            deletePhoto();
        } catch (Exception e) {
            log.error("Scheduler: deleteOldPhotos: deletePhoto()", e);
        }
        try {
            deleteAgPhoto();
        } catch (Exception e) {
            log.error("Scheduler: deleteOldPhotos: deleteAgPhoto()", e);
        }
    }

    private void deletePhoto() throws RepositoryException {
        log.debug("delete photo task");
        Session session = null;
        try {
            session = getSession();
            Node photoRootNode = getPhotoNode(session);
            if (photoRootNode == null) {
                throw new BadRequestException("ERROR_CODE_05", "Not initialized directory photo");
            }
            NodeIterator checkListNodes = photoRootNode.getNodes();
            if (checkListNodes == null) {
                throw new BadRequestException("ERROR_CODE_06", "Something went wrong");
            }
            DateTime controlDate = DateTime.now().minusDays(getDaysFromSavePhoto());
            while (checkListNodes.hasNext()) {
                Node checkListNode = checkListNodes.nextNode();
//                NodeIterator questionNodes = checkListNode.getNodes();
                try {
                    if (!checkListNode.getName().startsWith("jcr") && controlDate.isAfter(fmt.parseDateTime(checkListNode.getProperty("lastUpdate").getString()))) {
                        log.debug("Delete old checklist photo id =" + checkListNode.getName());
                        checkListNode.remove();
                        continue;
                    }
                } catch (Exception e) {
                    log.error("delete photo task", e);
                }
//                while (questionNodes.hasNext()) {
//                    Node questionNode = questionNodes.nextNode();
//                    NodeIterator photoNodes = questionNode.getNodes();
//                    while (photoNodes.hasNext()) {
//                        Node photoNode = photoNodes.nextNode();
//                        if (!photoNode.getName().startsWith("jcr") && controlDate.isAfter(fmt.parseDateTime(photoNode.getName()))) { //тут ошибка, имя фото не содержит даты, это UUID
//                            log.debug("Delete old photo id = " + photoNode.getName());
//                            photoNode.remove();
//                        }
//                    }
//                }
            }
            session.save();
        } catch (Exception e) {
            log.error("deletePhoto()", e);
        } finally {
            if(session != null) {
                session.logout();
            }
        }
    }

    private void deleteAgPhoto() throws RepositoryException {
        log.debug("delete AG photo task");
        Session session = getSession();
        try {
            Node photoRootNode = getPhotoAgNode(session);
            if (photoRootNode == null) {
                throw new BadRequestException("ERROR_CODE_05", "Not initialized directory photo");
            }
            NodeIterator shopNodes = photoRootNode.getNodes();
            if (shopNodes == null) {
                throw new BadRequestException("ERROR_CODE_06", "Something went wrong");
            }
            DateTime controlDate = DateTime.now().minusDays(getDaysFromSavePhotoAG());
            while (shopNodes.hasNext()) {
                Node shopNode = shopNodes.nextNode();
                if (!shopNode.getName().startsWith("jcr") && controlDate.isAfter(fmt.parseDateTime(shopNode.getProperty("lastUpdate").getString()))) {
                    log.debug("Delete old photo from shop id =" + shopNode.getName());
                    shopNode.remove();
                    continue;
                }
                NodeIterator photoNodes = shopNode.getNodes();
                while (photoNodes.hasNext()) {
                    Node photoNode = photoNodes.nextNode();
                    Property created = photoNode.hasProperty("created") ? photoNode.getProperty("created") : null;
                    if (!photoNode.getName().startsWith("jcr") && created != null && controlDate.isAfter(fmt.parseDateTime(created.getString()))) {
                        log.debug("Delete old ag_photo id = " + photoNode.getName());
                        photoNode.remove();
                    }
                }
            }
            session.save();
        } finally {
            session.logout();
        }
    }

    private Integer getDaysFromSavePhoto() {
        return getDaysFromSavePhoto(DAYS_FROM_SAVE_PHOTO, PROPERTIES_PROP_DAYS);
    }

    private Integer getDaysFromSavePhotoAG() {
        return getDaysFromSavePhoto(DAYS_FROM_SAVE_PHOTO_AG, PROPERTIES_PROP_DAYS_AG);
    }

    private Integer getDaysFromSavePhoto(Integer defaultDays, String propertyName) {
        Integer days = defaultDays;
        try {
            days = Integer.valueOf(getFileProperties().getProperty(propertyName));
        } catch (NumberFormatException | IOException ex) {
            log.error("IO error: create or read file photosetting.properties", ex);
        }
        return days;
    }

    private Session getSession() throws LoginException, RepositoryException {
        return repository.login(new SimpleCredentials("admin", "admin".toCharArray()));
    }

    private Node getPhotoNode(Session session) throws RepositoryException {
        return getPhotoNode(session, false);
    }

    private Node getPhotoAgNode(Session session) throws RepositoryException {
        return getPhotoAgNode(session, false);
    }

    private Node getPhotoNode(Session session, boolean createIfNotExist) throws RepositoryException {
        return getSubRootNode(session, NODE_NAME_PHOTO, createIfNotExist);
    }

    private Node getPhotoAgNode(Session session, boolean createIfNotExist) throws RepositoryException {
        return getSubRootNode(session, NODE_NAME_PHOTO_AG, createIfNotExist);
    }

    private Node getSubRootNode(Session session, String nodeName, boolean createIfNotExist) throws RepositoryException {
        Node root = session.getRootNode();
        Node node = JcrUtils.getNodeIfExists(root, nodeName);
        if (node != null || !createIfNotExist)
            return node;
        return root.addNode("./" + nodeName);
    }

    private void savePhoto(final String bucketName, final String photoName, final String contentType, final MultipartFile file) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        try (final InputStream stream = new ByteArrayInputStream(file.getBytes())) {
            //img = IOUtils.toByteArray(photoNode.getProperty("img").getBinary().getStream());
            this.minioClient.putObject(bucketName, photoName, stream, stream.available(), contentType);
        }
    }

    private List<PhotoCollectionDTO> findAllByChecklistId(final Integer checklistId) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        List<Bucket> bucketList = minioClient.listBuckets();
        List<Bucket> filtered = bucketList.stream().filter(b -> b.name().contains(Integer.toString(checklistId))).collect(Collectors.toList());
        List<String> names = filtered.stream().map(b -> b.name()).collect(Collectors.toList());
        names.stream().flatMap(n -> {
            try {
                b.
                return StreamSupport.stream(minioClient.listObjects(n).spliterator(), false);
            }
            catch (Exception ex) {
                return Stream.empty();
            }
        }).filter(r ->{
            try {
                return !(r.get().isDir());
            }
            catch (Exception ex) {
                return false;
            }
        })
        .map(r -> {
            try {
                Item item = r.get();
                item..storageClass()
            }
            catch (Exception ex) {

            }

        }).collect(Collectors.toList());


        filtered.stream().map(b -> {
            PhotoCollectionDTO dto = new PhotoCollectionDTO();
            dto.setPhotoId(b.name());
            dto.setQuestionId();
        });
        try (final InputStream stream = new ByteArrayInputStream(file.getBytes())) {
            //img = IOUtils.toByteArray(photoNode.getProperty("img").getBinary().getStream());
            this.minioClient.putObject(bucketName, photoName, stream, stream.available(), contentType);
        }
    }

    private List<PhotoCollectionDTO> findByChecklistAndQuestionId(final Integer checklistId, final Integer questionId) throws IOException, NoSuchAlgorithmException, InvalidKeyException, XmlPullParserException, MinioException {
        List<Bucket> bucketList = minioClient.listBuckets();
        return null;
    }

    private Properties getFileProperties() throws IOException {

        Properties prop = new Properties();
        File file = new File(PROPERTIES_FILE_NAME);
        if (!file.exists()) {
            prop.setProperty(PROPERTIES_PROP_DAYS, DAYS_FROM_SAVE_PHOTO.toString());
            prop.store(new FileOutputStream(file), "The number of days to store photos");
        }
        prop.load(new FileInputStream(file));
        return prop;
    }
}