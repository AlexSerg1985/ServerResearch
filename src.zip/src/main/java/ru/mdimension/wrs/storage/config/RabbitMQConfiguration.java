package ru.mdimension.wrs.storage.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.mdimension.wrs.storage.properties.RabbitMQProperties;

import javax.inject.Inject;

/**
 * Created by vkokurin on 10.11.2015.
 */
@Configuration
public class RabbitMQConfiguration {

    private final static Logger log = LoggerFactory.getLogger(RabbitMQConfiguration.class);

    @Inject
    private RabbitMQProperties properties;

    @Bean
    public CachingConnectionFactory cachingConnectionFactory() {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setHost(properties.getHost());
        connectionFactory.setUsername(properties.getUserName());
        connectionFactory.setPassword(properties.getPassword());
        return connectionFactory;
    }

    @Bean
    public RabbitTemplate rabbitTemplate() {
        RabbitTemplate template = new RabbitTemplate(cachingConnectionFactory());
        log.debug("Rabbit MQ configured");
        return template;
    }
}
