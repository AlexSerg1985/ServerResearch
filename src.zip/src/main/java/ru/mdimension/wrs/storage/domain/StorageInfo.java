package ru.mdimension.wrs.storage.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import ru.mdimension.wrs.core.util.JodaDateTimeDeserializer;
import ru.mdimension.wrs.core.util.JodaLocalDateSerializer;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "T_STORAGE_INFO", uniqueConstraints = {@UniqueConstraint(columnNames = {"FILE_NAME"})})
public class StorageInfo implements Serializable {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "storage_info_sequence")
    @SequenceGenerator(name = "storage_info_sequence", sequenceName = "storage_info_sequence", allocationSize = 1, initialValue = 1)
    private int id;

    @Column(name = "USER_LOGIN")
    private String userLogin;

    @Column(name = "BUCKET_NAME")
    private String bucketName;

    @Column(name = "CONTENT_TYPE")
    private String contentType;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "CREATE_DATE")
    @JsonSerialize(using = JodaLocalDateSerializer.class)
    @JsonDeserialize(using = JodaDateTimeDeserializer.class)
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    private DateTime createDate;

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public DateTime getCreateDate() {
        return createDate;
    }

    public void setCreateDate(DateTime createDate) {
        this.createDate = createDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
