package ru.mdimension.wrs.storage.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Created by vkokurin on 10.11.2015.
 */
@ConfigurationProperties(prefix = "rabbitmq", ignoreUnknownFields = false)
public class RabbitMQProperties {

    private String host;

    private String userName;

    private String password;

    private final Exchanges exchanges = new Exchanges();

    public static class Exchanges {

        private String wrsExchangePhoto;

        public String getWrsExchangePhoto() {
            return wrsExchangePhoto;
        }

        public void setWrsExchangePhoto(String wrsExchangePhoto) {
            this.wrsExchangePhoto = wrsExchangePhoto;
        }
    }

    public Exchanges getExchanges() {
        return exchanges;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}