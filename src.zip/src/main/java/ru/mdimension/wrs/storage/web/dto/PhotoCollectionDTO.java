package ru.mdimension.wrs.storage.web.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Created by vsachkov on 21.10.2015.
 */
@ApiModel
public class PhotoCollectionDTO {

    private String questionId;
    private String photoId;
    private byte [] photo2Base64;
    private String type;

    public PhotoCollectionDTO(byte [] photo2Base64) {
        this.photo2Base64 = photo2Base64;
    }

    public PhotoCollectionDTO(String questionId, String photoId) {
        this.photoId = photoId;
        this.questionId = questionId;
    }

    public PhotoCollectionDTO(String questionId, String photoId, byte [] photo2Base64) {
        this.questionId = questionId;
        this.photo2Base64 = photo2Base64;
        this.photoId = photoId;
    }

    public PhotoCollectionDTO(String questionId, String photoId, byte[] photo2Base64, String type) {
        this.questionId = questionId;
        this.photoId = photoId;
        this.photo2Base64 = photo2Base64;
        this.type = type;
    }

    @ApiModelProperty(notes = "id вопроса")
    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    @ApiModelProperty(notes = "фотография в base64")
    public byte [] getPhoto2Base64() {
        return photo2Base64;
    }

    public void setPhoto2Base64(byte [] photo2Base64) {
        this.photo2Base64 = photo2Base64;
    }

    @ApiModelProperty(notes = "UUID фотографии на сервере")
    public String getPhotoId() {
        return photoId;
    }

    public void setPhotoId(String photoId) {
        this.photoId = photoId;
    }

    @ApiModelProperty(notes = "тип данных - content-type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}