package ru.mdimension.wrs.storage.service;

import io.minio.MinioClient;
import io.minio.errors.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.xmlpull.v1.XmlPullParserException;
import ru.mdimension.wrs.storage.api.StorageApi;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@Component
public class StorageApiImpl implements StorageApi {

    private final Logger log = LoggerFactory.getLogger(StorageApiImpl.class);

    @Inject
    private MinioClient minioClient;

    @Override
    public boolean saveObject(@Nonnull String bucket, @Nonnull String objectName, byte[] object,
                              @Nonnull String contentType) {
        try {
            checkBucket(bucket);
            minioClient.putObject(bucket, objectName, new ByteArrayInputStream(object), object.length, contentType);
        } catch (Exception e) {
            log.error("[StorageApiImpl]", e);
            return false;
        }
        return true;
    }

    @Override
    public byte[] getObject(@Nonnull String bucket, @Nonnull String objectName) {
        try {
            checkBucket(bucket);
            return StreamUtils.copyToByteArray(minioClient.getObject(bucket, objectName));
        } catch (Exception e) {
            log.error("[StorageApiImpl]", e);
            return null;
        }
    }

    @Override
    public InputStream getObjectInputStream(@Nonnull String bucket, @Nonnull String objectName) {
        try {
            checkBucket(bucket);
            return minioClient.getObject(bucket, objectName);
        } catch (Exception e) {
            log.error("[StorageApiImpl]", e);
            return null;
        }
    }

    @Override
    public boolean deleteObject(@Nonnull String bucket, @Nonnull String objectName) {
        try {
            minioClient.removeObject(bucket, objectName);
        } catch (Exception e) {
            log.error("[StorageApiImpl]", e);
            return false;
        }
        return true;
    }

    private void checkBucket(String bucket) throws IOException, InvalidKeyException, NoSuchAlgorithmException,
            InsufficientDataException, InternalException, NoResponseException, InvalidBucketNameException,
            XmlPullParserException, ErrorResponseException, RegionConflictException {
        if (!minioClient.bucketExists(bucket)) {
            minioClient.makeBucket(bucket);
        }
    }
}
